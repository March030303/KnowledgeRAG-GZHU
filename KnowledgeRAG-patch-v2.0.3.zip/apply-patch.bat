@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

:title KnowledgeRAG v2.0.3 补丁安装程序

echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║     KnowledgeRAG v2.0.3  —  一键补丁程序                   ║
echo ║     新增：Mobile端RESTful路由 + 删除错误详情               ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

::: ── 获取补丁脚本所在目录 ──
set "PATCH_DIR=%~dp0"
set "PATCH_DIR=%PATCH_DIR:~0,-1%"

::: ═══════════════════════════════════════════════════════════════
::: 第1步：检测 KnowledgeRAG 安装目录
::: ═══════════════════════════════════════════════════════════════
echo [1/4] 检测 KnowledgeRAG 安装目录...

set "TARGET_DIR="
set "SEARCH_PATHS=D:\WorkBuddy\20260324003945\KnowledgeRAG-GZHU C:\KnowledgeRAG D:\KnowledgeRAG E:\KnowledgeRAG %USERPROFILE%\Desktop\KnowledgeRAG-GZHU"

for %%P in (%SEARCH_PATHS%) do (
    if exist "%%P\RagBackend\main.py" (
        set "TARGET_DIR=%%P"
        echo   ✅ 找到安装目录: %%P
        goto :found_target
    )
)

::: 方法2：询问用户
echo.
echo   [!] 未自动检测到 KnowledgeRAG 安装目录。
echo.
set /p "TARGET_DIR=请输入 KnowledgeRAG 的安装路径（如 D:\KnowledgeRAG）: "
if not exist "%TARGET_DIR%\RagBackend\main.py" (
    echo   [错误] 指定路径下未找到 RagBackend\main.py！
    echo   请确认路径正确后重试。
    pause
    exit /b 1
)
echo   ✅ 使用指定目录: %TARGET_DIR%

:found_target
echo.

::: ═══════════════════════════════════════════════════════════════
::: 第2步：创建备份
::: ═══════════════════════════════════════════════════════════════
echo [2/4] 备份原始文件...

::: 创建带时间戳的备份目录
for /f "tokens=1-3 delims=/ " %%a in ('date /t') do set "BACKUP_DATE=%%a%%b%%c"
for /f "tokens=1-2 delims=: " %%a in ('time /t') do set "BACKUP_TIME=%%a%%b"
set "BACKUP_TIME=%BACKUP_TIME: =0%"
set "BACKUP_DIR=%PATCH_DIR%\patch-backup\v2.0.3_%BACKUP_DATE%_%BACKUP_TIME%"

mkdir "%BACKUP_DIR%" 2>nul

set "BACKUP_COUNT=0"

::: 备份文件1：后端知识库模块
if exist "%TARGET_DIR%\RagBackend\knowledge_base\knowledgeBASE4CURD.py" (
    copy /y "%TARGET_DIR%\RagBackend\knowledge_base\knowledgeBASE4CURD.py" "%BACKUP_DIR%\knowledgeBASE4CURD.py" >nul 2>&1
    set /a BACKUP_COUNT+=1
)

::: 备份文件2：前端用户数据store
if exist "%TARGET_DIR%\RagFrontend\src\store\modules\useDataUser.ts" (
    copy /y "%TARGET_DIR%\RagFrontend\src\store\modules\useDataUser.ts" "%BACKUP_DIR%\useDataUser.ts" >nul 2>&1
    set /a BACKUP_COUNT+=1
)

::: 备份文件3：前端用户组件
if exist "%TARGET_DIR%\RagFrontend\src\components\user-primary\user-primary.vue" (
    copy /y "%TARGET_DIR%\RagFrontend\src\components\user-primary\user-primary.vue" "%BACKUP_DIR%\user-primary.vue" >nul 2>&1
    set /a BACKUP_COUNT+=1
)

::: 备份文件4：前端知识库页面（新增）
if exist "%TARGET_DIR%\RagFrontend\src\views\KnowledgePages\KnowledgeBase.vue" (
    copy /y "%TARGET_DIR%\RagFrontend\src\views\KnowledgePages\KnowledgeBase.vue" "%BACKUP_DIR%\KnowledgeBase.vue" >nul 2>&1
    set /a BACKUP_COUNT+=1
)

if %BACKUP_COUNT% lss 4 (
    echo   [警告] 仅备份了 %BACKUP_COUNT%/4 个文件，目标目录可能不完整
) else (
    echo   ✅ 已备份 4 个原始文件到: patch-backup\
)
echo.

::: ═══════════════════════════════════════════════════════════════
::: 第3步：应用补丁
::: ═══════════════════════════════════════════════════════════════
echo [3/4] 应用补丁文件...
set "PATCH_FILES=0"
set "PATCH_OK=0"

::: 补丁1：knowledgeBASE4CURD.py（后端核心 - RESTful路由+安全加固）
if exist "%PATCH_DIR%\patch\RagBackend\knowledge_base\knowledgeBASE4CURD.py" (
    set /a PATCH_FILES+=1
    copy /y "%PATCH_DIR%\patch\RagBackend\knowledge_base\knowledgeBASE4CURD.py" "%TARGET_DIR%\RagBackend\knowledge_base\knowledgeBASE4CURD.py" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a PATCH_OK+=1
        echo   ✅ knowledgeBASE4CURD.py （RESTful路由+安全加固）
    ) else (
        echo   ❌ knowledgeBASE4CURD.py 失败
    )
) else (
    echo   ⚠️ 补丁文件不存在: knowledgeBASE4CURD.py
)

::: 补丁2：useDataUser.ts（移除用户报错弹窗）
if exist "%PATCH_DIR%\patch\RagFrontend\src\store\modules\useDataUser.ts" (
    set /a PATCH_FILES+=1
    copy /y "%PATCH_DIR%\patch\RagFrontend\src\store\modules\useDataUser.ts" "%TARGET_DIR%\RagFrontend\src\store\modules\useDataUser.ts" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a PATCH_OK+=1
        echo   ✅ useDataUser.ts （移除用户数据报错弹窗）
    ) else (
        echo   ❌ useDataUser.ts 失败
    )
) else (
    echo   ⚠️ 补丁文件不存在: useDataUser.ts
)

::: 补丁3：user-primary.vue（移除用户报错弹窗）
if exist "%PATCH_DIR%\patch\RagFrontend\src\components\user-primary\user-primary.vue" (
    set /a PATCH_FILES+=1
    copy /y "%PATCH_DIR%\patch\RagFrontend\src\components\user-primary\user-primary.vue" "%TARGET_DIR%\RagFrontend\src\components\user-primary\user-primary.vue" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a PATCH_OK+=1
        echo   ✅ user-primary.vue （移除用户数据报错弹窗）
    ) else (
        echo   ❌ user-primary.vue 失败
    )
) else (
    echo   ⚠️ 补丁文件不存在: user-primary.vue
)

::: 补丁4：KnowledgeBase.vue（增强删除错误提示）[v2.0.3新增]
if exist "%PATCH_DIR%\patch\RagFrontend\src\views\KnowledgePages\KnowledgeBase.vue" (
    set /a PATCH_FILES+=1
    copy /y "%PATCH_DIR%\patch\RagFrontend\src\views\KnowledgePages\KnowledgeBase.vue" "%TARGET_DIR%\RagFrontend\src\views\KnowledgePages\KnowledgeBase.vue" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a PATCH_OK+=1
        echo   ✅ KnowledgeBase.vue （删除错误详情显示）
    ) else (
        echo   ❌ KnowledgeBase.vue 失败
    )
) else (
    echo   ⚠️ 补丁文件不存在: KnowledgeBase.vue
)
echo.

::: ═══════════════════════════════════════════════════════════════
::: 第4步：结果 & 重启提示
::: ═══════════════════════════════════════════════════════════════
echo [4/4] 验证结果...

if %PATCH_OK% equ 4 (
    echo.
    echo ╔═══════════════════════════════════════════════════════════╗
    echo ║                  🎉 补丁安装成功！                       ║
    echo ╠═══════════════════════════════════════════════════════════╣
    echo ║                                                       ║
    echo ║   已修复：                                             ║
    echo ║   ✓ Mobile 端 RESTful 路由兼容（不再404）              ║
    echo ║   ✓ 删除失败时显示具体错误原因                         ║
    echo ║   ✓ 知识库排序容错保护                                 ║
    echo ║   ✓ 不再弹出「获取用户数据失败」报错                   ║
    echo ║   ✓ 路径遍历攻击防护                                   ║
    echo ║                                                       ║
    echo ║   备份位置：%BACKUP_DIR%                                ║
    echo ╚═══════════════════════════════════════════════════════════╝
    echo.

    :: 提示重启
    set /p "RESTART=是否立即重启前后端服务？(Y/n): "
    if /i "%RESTART%"=="n" goto :skip_restart
    if /i "%RESTART%"=="no" goto :skip_restart

    echo.
    echo [*] 正在停止旧服务进程...
    taskkill /fi "WINDOWTITLE eq KnowledgeRAG-Backend*" /f >nul 2>&1
    taskkill /fi "WINDOWTITLE eq KnowledgeRAG-Frontend*" /f >nul 2>&1
    taskkill /im python.exe /fi "WINDOWTITLE eq KnowledgeRAG*" /f >nul 2>&1
    timeout /t 2 /nobreak >nul 2>&1
    echo   ✅ 旧进程已停止

    echo [*] 启动后端...
    cd /d "%TARGET_DIR%\RagBackend"
    start "KnowledgeRAG-Backend" python main.py
    timeout /t 5 /nobreak >nul 2>&1

    echo [*] 启动前端...
    cd /d "%TARGET_DIR%\RagFrontend"
    start "KnowledgeRAG-Frontend" cmd /k "corepack pnpm dev"
    timeout /t 3 /nobreak >nul 2>&1

    echo.
    echo ✅ 服务已重启！
echo   前端: http://127.0.0.1:5173
echo   后端: http://127.0.0.1:8000/docs
    timeout /t 3 /nobreak >nul 2>&1
    start http://127.0.0.1:5173

) else (
    echo.
    echo   [❌] 补丁安装不完全（%PATCH_OK%/4 成功）
    echo   请检查目标目录是否正确，或尝试手动替换。
)

:skip_restart
echo.
pause
