@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

title KnowledgeRAG v2.0.2 补丁安装程序

echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║     KnowledgeRAG v2.0.2  —  一键补丁程序                   ║
echo ║     修复：知识库获取失败 + 用户数据报错弹窗               ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

:: ── 获取补丁脚本所在目录 ──
set "PATCH_DIR=%~dp0"
set "PATCH_DIR=%PATCH_DIR:~0,-1%"

:: ═══════════════════════════════════════════════════════════════
:: 第1步：检测 KnowledgeRAG 安装目录
:: ═══════════════════════════════════════════════════════════════
echo [1/4] 检测 KnowledgeRAG 安装目录...

:: 方法1：从注册表或常见路径查找
set "TARGET_DIR="
set "SEARCH_PATHS=D:\WorkBuddy\20260324003945\KnowledgeRAG-GZHU C:\KnowledgeRAG D:\KnowledgeRAG E:\KnowledgeRAG %USERPROFILE%\Desktop\KnowledgeRAG-GZHU"

for %%P in (%SEARCH_PATHS%) do (
    if exist "%%P\RagBackend\main.py" (
        set "TARGET_DIR=%%P"
        echo   ✅ 找到安装目录: %%P
        goto :found_target
    )
)

:: 方法2：询问用户
echo.
echo   [!] 未自动检测到 KnowledgeRAG 安装目录。
echo.
set /p "TARGET_DIR=请输入 KnowledgeRAG 的安装路径（如 D:\KnowledgeRAG）: "
if not exist "%TARGET_DIR%\RagBackend\main.py" (
    echo   [错误] 指定路径下未找到 RagBackend\main.py！
    echo   请确认路径正确后重试。
    pause
    exit /b 1
)
echo   ✅ 使用指定目录: %TARGET_DIR%

:found_target
echo.

:: ═══════════════════════════════════════════════════════════════
:: 第2步：创建备份
:: ═══════════════════════════════════════════════════════════════
echo [2/4] 备份原始文件...

:: 创建带时间戳的备份目录
for /f "tokens=1-3 delims=/ " %%a in ('date /t') do set "BACKUP_DATE=%%a%%b%%c"
for /f "tokens=1-2 delims=: " %%a in ('time /t') do set "BACKUP_TIME=%%a%%b"
set "BACKUP_TIME=%BACKUP_TIME: =0%"
set "BACKUP_DIR=%PATCH_DIR%\patch-backup\v2.0.2_%BACKUP_DATE%_%BACKUP_TIME%"

mkdir "%BACKUP_DIR%" 2>nul

set "BACKUP_COUNT=0"

:: 备份文件1：后端知识库模块
if exist "%TARGET_DIR%\RagBackend\knowledge_base\knowledgeBASE4CURD.py" (
    copy /y "%TARGET_DIR%\RagBackend\knowledge_base\knowledgeBASE4CURD.py" "%BACKUP_DIR%\knowledgeBASE4CURD.py" >nul 2>&1
    set /a BACKUP_COUNT+=1
)

:: 备份文件2：前端用户数据store
if exist "%TARGET_DIR%\RagFrontend\src\store\modules\useDataUser.ts" (
    copy /y "%TARGET_DIR%\RagFrontend\src\store\modules\useDataUser.ts" "%BACKUP_DIR%\useDataUser.ts" >nul 2>&1
    set /a BACKUP_COUNT+=1
)

:: 备份文件3：前端用户组件
if exist "%TARGET_DIR%\RagFrontend\src\components\user-primary\user-primary.vue" (
    copy /y "%TARGET_DIR%\RagFrontend\src\components\user-primary\user-primary.vue" "%BACKUP_DIR%\user-primary.vue" >nul 2>&1
    set /a BACKUP_COUNT+=1
)

if %BACKUP_COUNT% lss 3 (
    echo   [警告] 仅备份了 %BACKUP_COUNT%/3 个文件，目标目录可能不完整
) else (
    echo   ✅ 已备份 3 个原始文件到: patch-backup\
)
echo.

:: ═══════════════════════════════════════════════════════════════
:: 第3步：应用补丁
:: ═══════════════════════════════════════════════════════════════
echo [3/4] 应用补丁文件...
set "PATCH_FILES=0"
set "PATCH_OK=0"

:: 补丁1：knowledgeBASE4CURD.py
if exist "%PATCH_DIR%\patch\RagBackend\knowledge_base\knowledgeBASE4CURD.py" (
    set /a PATCH_FILES+=1
    copy /y "%PATCH_DIR%\patch\RagBackend\knowledge_base\knowledgeBASE4CURD.py" "%TARGET_DIR%\RagBackend\knowledge_base\knowledgeBASE4CURD.py" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a PATCH_OK+=1
        echo   ✅ knowledgeBASE4CURD.py （知识库排序容错修复）
    ) else (
        echo   ❌ knowledgeBASE4CURD.py 失败
    )
) else (
    echo   ⚠️ 补丁文件不存在: knowledgeBASE4CURD.py
)

:: 补丁2：useDataUser.ts
if exist "%PATCH_DIR%\patch\RagFrontend\src\store\modules\useDataUser.ts" (
    set /a PATCH_FILES+=1
    copy /y "%PATCH_DIR%\patch\RagFrontend\src\store\modules\useDataUser.ts" "%TARGET_DIR%\RagFrontend\src\store\modules\useDataUser.ts" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a PATCH_OK+=1
        echo   ✅ useDataUser.ts （移除用户数据报错弹窗）
    ) else (
        echo   ❌ useDataUser.ts 失败
    )
) else (
    echo   ⚠️ 补丁文件不存在: useDataUser.ts
)

:: 补丁3：user-primary.vue
if exist "%PATCH_DIR%\patch\RagFrontend\src\components\user-primary\user-primary.vue" (
    set /a PATCH_FILES+=1
    copy /y "%PATCH_DIR%\patch\RagFrontend\src\components\user-primary\user-primary.vue" "%TARGET_DIR%\RagFrontend\src\components\user-primary\user-primary.vue" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a PATCH_OK+=1
        echo   ✅ user-primary.vue （移除用户数据报错弹窗）
    ) else (
        echo   ❌ user-primary.vue 失败
    )
) else (
    echo   ⚠️ 补丁文件不存在: user-primary.vue
)
echo.

:: ═══════════════════════════════════════════════════════════════
:: 第4步：结果 & 重启提示
:: ═══════════════════════════════════════════════════════════════
echo [4/4] 验证结果...

if %PATCH_OK% equ 3 (
    echo.
    echo ╔═══════════════════════════════════════════════════════════╗
    echo ║                  🎉 补丁安装成功！                       ║
    echo ╠═══════════════════════════════════════════════════════════╣
    echo ║                                                       ║
    echo ║   已修复：                                             ║
    echo ║   ✓ 知识库列表不再 500 崩溃                             ║
    echo ║   ✓ 不再弹出「获取用户数据失败」报错                    ║
    echo ║                                                       ║
    echo ║   备份位置：%BACKUP_DIR%                                ║
    echo ╚═══════════════════════════════════════════════════════════╝
    echo.

    :: 提示重启
    set /p "RESTART=是否立即重启前后端服务？(Y/n): "
    if /i "%RESTART%"=="n" goto :skip_restart
    if /i "%RESTART%"=="no" goto :skip_restart

    echo.
    echo [*] 正在停止旧服务进程...
    taskkill /fi "WINDOWTITLE eq KnowledgeRAG-Backend*" /f >nul 2>&1
    taskkill /fi "WINDOWTITLE eq KnowledgeRAG-Frontend*" /f >nul 2>&1
    taskkill /im python.exe /fi "WINDOWTITLE eq KnowledgeRAG*" /f >nul 2>&1
    timeout /t 2 /nobreak >nul 2>&1
    echo   ✅ 旧进程已停止

    echo [*] 启动后端...
    cd /d "%TARGET_DIR%\RagBackend"
    start "KnowledgeRAG-Backend" python main.py
    timeout /t 5 /nobreak >nul 2>&1

    echo [*] 启动前端...
    cd /d "%TARGET_DIR%\RagFrontend"
    start "KnowledgeRAG-Frontend" cmd /k "corepack pnpm dev"
    timeout /t 3 /nobreak >nul 2>&1

    echo.
    echo ✅ 服务已重启！
    echo   前端: http://localhost:5173
    echo   后端: http://localhost:8000/docs
    timeout /t 3 /nobreak >nul 2>&1
    start http://localhost:5173

) else (
    echo.
    echo   [❌] 补丁安装不完全（%PATCH_OK%/3 成功）
    echo   请检查目标目录是否正确，或尝试手动替换。
)

:skip_restart
echo.
pause
