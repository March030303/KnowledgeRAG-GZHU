@echo off
chcp 65001 >nul 2>&1
echo ╔══════════════════════════════════════════════════╗
echo ║     KnowledgeRAG v2.0 离线安装程序               ║
echo ║     智能知识库系统 - Docker 离线版              ║
echo ╚══════════════════════════════════════════════════╝
echo.

:: ── 第1步：检查 Docker ────────────────────────────────
echo [1/4] 检查 Docker 环境...
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo   [错误] 未检测到 Docker Desktop！
    echo   请先安装：https://www.docker.com/products/docker-desktop/
    echo   安装完成后重新运行此脚本。
    echo.
    pause
    exit /b 1
)
echo   ✅ Docker 已安装: 
docker --version
echo.

:: ── 第2步：导入离线镜像 ────────────────────────────────
echo [2/4] 导入离线镜像（约 3.5 GB，请耐心等待）...

:: 检查是否为分割文件
if exist "knowledge-rag-v2.tar" (
    echo   发现完整镜像文件，直接导入...
    docker load -i knowledge-rag-v2.tar
) else if exist "knowledge-rag-v2.tar.part1" (
    echo   发现分卷文件，正在合并...
    copy /b knowledge-rag-v2.tar.part1+knowledge-rag-v2.tar.part2 knowledge-rag-v2.tar
    if %errorlevel% neq 0 (
        echo   [错误] 分卷合并失败！请确保所有分卷文件都在同一目录。
        pause
        exit /b 1
    )
    echo   合并完成，正在导入 Docker...
    docker load -i knowledge-rag-v2.tar
) else (
    echo   [错误] 找不到镜像文件！
    echo   需要 knowledge-rag-v2.tar 或 knowledge-rag-v2.tar.part1 + .part2
    pause
    exit /b 1
)

if %errorlevel% neq 0 (
    echo   [错误] 镜像导入失败！请检查磁盘空间。
    pause
    exit /b 1
)
echo   ✅ 镜像导入成功
echo.

:: ── 第3步：创建配置文件 ────────────────────────────────
echo [3/4] 初始化配置...
if not exist ".env" (
    echo DEEPSEEK_API_KEY=sk-e5b9e14d94224cf9863d76cf8d32c199 > .env
    echo JWT_SECRET=knowledgeRAG_gzhu_2025_secure_v2 >> .env
    echo   ✅ 配置文件已创建 (.env)
) else (
    echo   ℹ️  配置文件已存在，跳过创建
)
echo.

:: ── 第4步：启动服务 ──────────────────────────────────
echo [4/4] 启动 KnowledgeRAG 服务...
docker compose -f docker-compose.offline.yml up -d
if %errorlevel% neq 0 (
    echo   [错误] 启动失败！请检查 Docker 是否正常运行。
    pause
    exit /b 1
)
echo.
echo ╔══════════════════════════════════════════════════╗
echo ║              🎉 安装完成！                      ║
echo ╠══════════════════════════════════════════════════╣
echo ║                                              ║
echo ║   前端界面: http://localhost:8089             ║
echo ║   后端API:  http://localhost:8000/docs         ║
echo ║                                              ║
echo ║   首次启动需要约 30-60 秒初始化...            ║
echo ║                                              ║
echo ║   停止服务: docker compose -f docker-compose.offline.yml down
echo ║   查看日志: docker compose -f docker-compose.offline.yml logs -f
echo ║                                              ║
echo ╚══════════════════════════════════════════════════╝
echo.
pause
